# City Air Quality Comparison

An educational, interactive environmental data-analysis web application built with **Python**, **Pandas**, **NumPy**, and **Streamlit**.

Designed specifically for undergraduate data science and computer applications students (BCA / B.Sc / B.Tech), this project demonstrates responsible data handling, transparent data quality validation, aggregation, threshold queries, and native visualization without reliance on heavy machine-learning packages or black-box libraries.

---

## 🌐 Live Website

- **Deployment URL:** `https://your-app-name.streamlit.app` *(Placeholder — replace with your actual Streamlit Community Cloud URL upon deployment)*

---

## 📌 Project Overview

Urban air quality is one of the most critical environmental metrics affecting public health, urban planning, and environmental justice. This application allows users to explore, compare, and validate air quality observations across multiple cities using the **Indian National Air Quality Index (NAQI)** standard published by the Central Pollution Control Board (CPCB).

### Key Educational Objectives
1. **Explore City Observations:** Inspect individual sensor readings with multi-attribute filtering and sorting.
2. **Compare Environmental Indicators:** Analyze average AQI, $\text{PM}_{2.5}$, $\text{PM}_{10}$, $\text{NO}_2$, $\text{SO}_2$, and $\text{CO}$ across cities.
3. **Rank Urban Centers:** Rank cities objectively by average valid AQI while explicitly recognizing that a higher AQI corresponds to poorer air quality.
4. **Evaluate Critical Thresholds:** Filter observations exceeding user-defined and standard reference thresholds (e.g., CPCB 24-hour limits).
5. **Analyze Category Distribution:** Categorize observations into official NAQI tiers with exact percentage shares.
6. **Audit Data Quality & Integrity:** Identify missing values, impossible negative concentrations, duplicate IDs, and out-of-scale values transparently without silent deletion.
7. **Add New Observations:** Input new records through an interactive form equipped with input validation.

---

## 🛠️ Technology Stack & Library Restrictions

This project strictly adheres to minimal, beginner-friendly core data science libraries:

| Technology | Purpose |
| :--- | :--- |
| **Python 3.9+** | Core programming language, functions, loops, conditions, exception handling |
| **Pandas** | DataFrame structures, CSV reading/writing, grouping (`groupby`), aggregation, filtering, missing-value detection |
| **NumPy** | Numerical array manipulation, safe NaN representation |
| **Streamlit** | Compact header, horizontal tab navigation (`st.tabs`), form controls, metric cards, native charts (`st.bar_chart`) |
| **CSV** | Transparent flat-file storage and exchange (`city_air_quality.csv`) |

> **Strict Architectural Boundary:** This project does not use Matplotlib, Seaborn, Plotly, Altair, Bokeh, Scikit-learn, external machine-learning models, or separate database servers. All visualizations use native Streamlit components.

---

## 📊 Dataset Schema & Synthetic Notice

The dataset is stored in `city_air_quality.csv` and contains synthetic sample records created for educational analysis.

> ⚠️ **Notice:** All included records are synthetic sample observations. They do not represent real-time, live measurements, or official municipal declarations.

### Column Specifications

| Column Name | Data Type | Educational Unit | Description |
| :--- | :--- | :--- | :--- |
| `Observation_ID` | String | Identifier | Unique code for the measurement event (e.g. `OBS001`) |
| `City` | String | Categorical | Urban center where the measurement was recorded |
| `Observation_Date` | String | YYYY-MM-DD | Date of observation |
| `AQI` | Float / Int | Unitless (0–500) | Air Quality Index value |
| `PM2_5` | Float | $\mu\text{g/m}^3$ | Fine particulate matter ($\le 2.5\ \mu\text{m}$) |
| `PM10` | Float | $\mu\text{g/m}^3$ | Inhalable coarse particulate matter ($\le 10\ \mu\text{m}$) |
| `NO2` | Float | $\mu\text{g/m}^3$ | Nitrogen dioxide concentration |
| `SO2` | Float | $\mu\text{g/m}^3$ | Sulfur dioxide concentration |
| `CO` | Float | $\text{mg/m}^3$ | Carbon monoxide concentration |

### Intentional Anomalies for Data Quality Education
To teach robust data cleaning, the dataset intentionally incorporates a small number of realistic anomalies:
- **Duplicate Observation ID:** `OBS010` is repeated to demonstrate key validation.
- **Missing AQI:** Blank value demonstrating missing-value handling.
- **Negative AQI:** `-25` (AQI is non-negative by definition).
- **Out-of-Scale AQI:** `550` (exceeds standard CPCB 0–500 scale).
- **Negative Pollutant Concentration:** $\text{PM}_{2.5} = -8.5\ \mu\text{g/m}^3$ (mass concentration cannot be negative; represents zero-drift sensor error).
- **Missing City Name:** Blank entry demonstrating grouping filter requirements.
- **Invalid Date Format:** `2024-99-99` demonstrating date parsing validation.
- **Missing Pollutant Reading:** Blank $\text{SO}_2$ value demonstrating partial record usability.

---

## 📐 AQI Classification Methodology

This application implements the official **CPCB National Air Quality Index (NAQI)** scale of India:

| Category | AQI Range | General Health Advisory |
| :--- | :---: | :--- |
| **Good** | 0 – 50 | Minimal impact; clean air conditions. |
| **Satisfactory** | 51 – 100 | Minor breathing discomfort to sensitive individuals. |
| **Moderately Polluted** | 101 – 200 | Breathing discomfort to people with asthma, lung, or heart disease. |
| **Poor** | 201 – 300 | Breathing discomfort to most people on prolonged exposure. |
| **Very Poor** | 301 – 400 | Respiratory illness on prolonged exposure. |
| **Severe** | 401 – 500 | Seriously impacts people with existing diseases and affects healthy people. |

### Scientific Responsibility Rules
1. **Range Enforcement:** Negative values and values above 500 are treated as invalid/out-of-scale and are **never** assigned a category.
2. **Missing Value Exclusion:** Unobserved AQI values are not classified and are not converted to zero.
3. **No Fabricated Conversions:** Official AQI calculation requires specific 24-hour sub-index equations and minimum pollutant coverage. This application classifies the directly supplied AQI and analyzes pollutant concentrations independently.
4. **Non-Medical Language:** Descriptions characterize general air pollution severity; they do not diagnose personal health conditions.

---

## 🗂️ Project File Structure

```
City-Air-Quality-Comparison/
├── app.py                      # Main Streamlit application and UI navigation
├── air_quality_analysis.py     # Modular data analysis and validation functions
├── city_air_quality.csv        # Documented synthetic sample dataset
├── requirements.txt            # Minimal runtime dependencies
├── run_app.bat                 # Windows one-click launcher with error checks
├── .gitignore                  # Git exclusion rules
├── .streamlit/
│   └── config.toml             # Custom styling and theme settings
└── README.md                   # Comprehensive project documentation
```

---

## 💻 Local Setup & Execution Guide

### Prerequisites
- A Windows, macOS, or Linux computer.
- Python 3.9 or higher installed ([Download Python](https://www.python.org/downloads/)).
  - *Windows Users:* Check the box **"Add Python to PATH"** during installation.

### Method 1: Using the Windows Launcher (`run_app.bat`)
1. Double-click `run_app.bat` inside the project folder.
2. The launcher will automatically verify Python, install any missing dependencies from `requirements.txt`, and start the Streamlit application.
3. If an error occurs, the window stays open to display diagnostic information.

### Method 2: Manual Terminal Execution (Windows / macOS / Linux)

1. **Open your terminal or command prompt** and navigate to the project directory:
   ```bash
   cd "C:\path\to\City air quality"
   ```

2. **(Optional but recommended) Create and activate a virtual environment:**
   - On Windows:
     ```bash
     python -m venv venv
     venv\Scripts\activate
     ```
   - On macOS/Linux:
     ```bash
     python3 -m venv venv
     source venv/bin/activate
     ```

3. **Install the minimal dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

4. **Launch the application:**
   ```bash
   streamlit run app.py
   ```

5. Open your web browser and visit the local URL displayed in the terminal:
   ```
   http://localhost:8501
   ```

---

## 🚀 GitHub Upload and Streamlit Community Cloud Deployment

### Step 1: Push Project to GitHub

1. Initialize git and commit your files:
   ```bash
   git init
   git add .
   git commit -m "Initial commit: City Air Quality Comparison project"
   ```

2. Create a new public repository on [GitHub](https://github.com/new) named `city-air-quality-comparison`.

3. Link your local repository and push:
   ```bash
   git branch -M main
   git remote add origin https://github.com/<your-username>/city-air-quality-comparison.git
   git push -u origin main
   ```

### Step 2: Deploy to Streamlit Community Cloud

1. Go to [share.streamlit.io](https://share.streamlit.io/) and sign in with your GitHub account.
2. Click **"New app"**.
3. Fill in the deployment form:
   - **Repository:** `<your-username>/city-air-quality-comparison`
   - **Branch:** `main`
   - **Main file path:** `app.py`
4. Click **"Deploy!"**.
5. Once deployment completes, copy your live URL (e.g., `https://city-air-quality-comparison.streamlit.app`) and update the **Live Website** section at the top of this `README.md`.

> **Note on Cloud File Persistence:** Streamlit Community Cloud runs apps inside ephemeral Linux containers. Observations added through the "Add Observation" form will be available during that active web session, but files modified in ephemeral containers do not persist permanently across container reboots. In a production enterprise system, an external database (such as PostgreSQL or Firestore) would be connected.

---

## 🔍 Data Quality Rules Summary

| Check | Rule | Handling in Analysis |
| :--- | :--- | :--- |
| **Observation ID** | Must be non-blank and unique | Flagged in audit; rejected on form submission |
| **City Name** | Must be non-blank string | Flagged in audit; excluded from city groupby |
| **Observation Date** | Must match `YYYY-MM-DD` | Flagged in audit; excluded from date filters |
| **AQI Range** | $0 \le \text{AQI} \le 500$ | Negative and $>500$ values excluded from city mean and category counts |
| **Pollutant Mass** | $\text{Concentration} \ge 0$ | Negative values treated as invalid sensor artifacts and excluded from averages |
| **Missing Values** | Not treated as zero | Excluded from numerators/denominators transparently |

---

## ⚖️ Academic and Analytical Integrity

- **Sample Purpose:** Built strictly for educational data science coursework.
- **No Diagnostic Claims:** Environmental index categories describe ambient conditions, not individual clinical health diagnoses.
- **Transparent Attribution:** Classification ranges are based on the published Central Pollution Control Board (CPCB) NAQI technical guidelines.
