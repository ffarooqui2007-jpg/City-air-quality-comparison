"""
test_project.py
===============
Comprehensive automated test suite for the City Air Quality Comparison project.
Validates all requirements specified in Section 14 of the prompt.
"""

import sys
import os
import py_compile
import pandas as pd
import numpy as np

import air_quality_analysis as aqa

def test_syntax():
    """1. Check that all Python files have valid syntax."""
    py_files = ["app.py", "air_quality_analysis.py"]
    for f in py_files:
        py_compile.compile(f, doraise=True)
    print("[PASS] Test 1 Passed: All Python files have valid syntax.")

def test_imports():
    """2. Check that required imports are present."""
    import streamlit
    import pandas
    import numpy
    print("[PASS] Test 2 Passed: Streamlit, Pandas, and NumPy are present and importable.")

def test_csv_columns():
    """3. Confirm that the CSV columns match application's expectations."""
    df, err = aqa.load_air_quality_data("city_air_quality.csv")
    assert err is None, f"Failed to load CSV: {err}"
    is_valid, missing = aqa.validate_columns(df)
    assert is_valid, f"Missing columns: {missing}"
    assert set(aqa.REQUIRED_COLUMNS).issubset(set(df.columns))
    print("[PASS] Test 3 Passed: CSV columns match all required specifications.")

def test_aqi_category_boundaries():
    """4. Test AQI category boundaries according to CPCB standard."""
    # Boundary tests
    assert aqa.classify_aqi(0) == "Good"
    assert aqa.classify_aqi(50) == "Good"
    assert aqa.classify_aqi(51) == "Satisfactory"
    assert aqa.classify_aqi(100) == "Satisfactory"
    assert aqa.classify_aqi(101) == "Moderately Polluted"
    assert aqa.classify_aqi(200) == "Moderately Polluted"
    assert aqa.classify_aqi(201) == "Poor"
    assert aqa.classify_aqi(300) == "Poor"
    assert aqa.classify_aqi(301) == "Very Poor"
    assert aqa.classify_aqi(400) == "Very Poor"
    assert aqa.classify_aqi(401) == "Severe"
    assert aqa.classify_aqi(500) == "Severe"

    # Out of boundary and invalid tests
    assert aqa.classify_aqi(-1) is None
    assert aqa.classify_aqi(501) is None
    assert aqa.classify_aqi(np.nan) is None
    assert aqa.classify_aqi(None) is None
    assert aqa.classify_aqi("invalid") is None
    print("[PASS] Test 4 Passed: AQI category boundaries and edge cases correctly classified.")

def test_missing_and_invalid_values():
    """5. Test missing and invalid numeric values handling."""
    df, _ = aqa.load_air_quality_data("city_air_quality.csv")
    quality = aqa.check_data_quality(df)
    assert quality["missing_counts"]["AQI"] >= 1
    assert quality["missing_city_count"] >= 1
    assert quality["invalid_dates_count"] >= 1
    print("[PASS] Test 5 Passed: Missing and invalid values accurately identified.")

def test_negative_values():
    """6. Test negative AQI and pollutant concentrations."""
    df, _ = aqa.load_air_quality_data("city_air_quality.csv")
    quality = aqa.check_data_quality(df)
    assert quality["negative_aqi_count"] >= 1
    assert quality["negative_pollutant_count"] >= 1
    assert quality["out_of_range_aqi_count"] >= 1
    print("[PASS] Test 6 Passed: Negative AQI and pollutant concentrations detected.")

def test_duplicate_ids():
    """7. Test duplicate observation IDs."""
    df, _ = aqa.load_air_quality_data("city_air_quality.csv")
    quality = aqa.check_data_quality(df)
    assert quality["duplicate_ids_count"] >= 1
    print("[PASS] Test 7 Passed: Duplicate observation IDs correctly flagged.")

def test_city_averages_and_rankings():
    """8. Test city averages and ranking calculations."""
    df, _ = aqa.load_air_quality_data("city_air_quality.csv")
    averages = aqa.calculate_city_averages(df, min_valid_obs=2)
    assert not averages.empty
    assert "Average_AQI" in averages.columns
    assert "Average_PM2_5" in averages.columns
    assert "Average_PM10" in averages.columns

    # Check ranking (higher AQI = Rank 1)
    ranked, insuff = aqa.rank_cities_by_aqi(df, min_valid_obs=2, higher_is_worse=True)
    assert not ranked.empty
    assert ranked.iloc[0]["Rank"] == 1
    assert ranked.iloc[0]["Average_AQI"] >= ranked.iloc[-1]["Average_AQI"]
    print("[PASS] Test 8 Passed: City averages and rankings correctly calculated without distortions.")

def test_threshold_filters_and_categories():
    """9. Test threshold filters and category counts."""
    df, _ = aqa.load_air_quality_data("city_air_quality.csv")
    # Threshold filter
    res = aqa.filter_by_threshold(df, aqi_thresh=200, condition=">=")
    assert not res.empty
    assert all(res["AQI"] >= 200)

    # Category counts
    cat_summary, total_valid, excluded = aqa.count_aqi_categories(df)
    assert len(cat_summary) == 6
    assert cat_summary["Count"].sum() == total_valid
    assert round(cat_summary["Percentage (%)"].sum(), 0) in (99.0, 100.0, 101.0) # Floating point rounding
    print("[PASS] Test 9 Passed: Threshold filters and category percentage calculations verified.")

def test_empty_filtered_results():
    """10. Test empty filtered results."""
    df, _ = aqa.load_air_quality_data("city_air_quality.csv")
    empty_res = aqa.filter_by_threshold(df, aqi_thresh=9999, condition=">=")
    assert empty_res.empty
    print("[PASS] Test 10 Passed: Empty filtered results handled safely.")

def test_add_valid_observation():
    """11. Test adding a valid observation."""
    df, _ = aqa.load_air_quality_data("city_air_quality.csv")
    is_valid, errors, record = aqa.validate_new_observation(
        existing_df=df,
        obs_id="OBS999",
        city="Mysuru",
        obs_date="2024-03-20",
        aqi=45,
        pm2_5=18.5,
        pm10=42.0,
        no2=20.0,
        so2=8.0,
        co=0.5,
    )
    assert is_valid, f"Validation failed unexpectedly: {errors}"
    assert record["Observation_ID"] == "OBS999"
    assert record["City"] == "Mysuru"
    assert record["AQI"] == 45
    print("[PASS] Test 11 Passed: Valid observation successfully validated.")

def test_reject_invalid_observations():
    """12. Test that invalid observations are rejected with clear messages."""
    df, _ = aqa.load_air_quality_data("city_air_quality.csv")
    # Duplicate ID
    is_v1, errs1, _ = aqa.validate_new_observation(df, "OBS001", "Delhi", "2024-03-20", 100, 30, 60, 20, 10, 1)
    assert not is_v1 and any("already exists" in e for e in errs1)

    # Negative AQI
    is_v2, errs2, _ = aqa.validate_new_observation(df, "OBS998", "Delhi", "2024-03-20", -50, 30, 60, 20, 10, 1)
    assert not is_v2 and any("cannot be negative" in e for e in errs2)

    # AQI > 500
    is_v3, errs3, _ = aqa.validate_new_observation(df, "OBS998", "Delhi", "2024-03-20", 550, 30, 60, 20, 10, 1)
    assert not is_v3 and any("cannot exceed 500" in e for e in errs3)

    # Negative pollutant
    is_v4, errs4, _ = aqa.validate_new_observation(df, "OBS998", "Delhi", "2024-03-20", 100, -15, 60, 20, 10, 1)
    assert not is_v4 and any("cannot be negative" in e for e in errs4)

    # Invalid Date
    is_v5, errs5, _ = aqa.validate_new_observation(df, "OBS998", "Delhi", "invalid-date", 100, 15, 60, 20, 10, 1)
    assert not is_v5 and any("YYYY-MM-DD" in e for e in errs5)

    print("[PASS] Test 12 Passed: Invalid observations rejected with explanatory messages.")

def test_file_structure():
    """13 & 14. Check file structure, README, and relative paths."""
    required_files = [
        "app.py",
        "air_quality_analysis.py",
        "city_air_quality.csv",
        "README.md",
        "requirements.txt",
        "run_app.bat",
        ".gitignore",
        os.path.join(".streamlit", "config.toml"),
    ]
    for rf in required_files:
        assert os.path.exists(rf), f"Missing required file: {rf}"
    print("[PASS] Tests 13 & 14 Passed: All required files exist and use project-relative paths.")

if __name__ == "__main__":
    print("Starting automated test verification...")
    test_syntax()
    test_imports()
    test_csv_columns()
    test_aqi_category_boundaries()
    test_missing_and_invalid_values()
    test_negative_values()
    test_duplicate_ids()
    test_city_averages_and_rankings()
    test_threshold_filters_and_categories()
    test_empty_filtered_results()
    test_add_valid_observation()
    test_reject_invalid_observations()
    test_file_structure()
    print("\n[SUCCESS] ALL 14 TEST SUITES PASSED SUCCESSFULLY!")
