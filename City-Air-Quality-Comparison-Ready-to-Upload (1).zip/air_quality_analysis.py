"""
air_quality_analysis.py
=======================
Core data-analysis module for the City Air Quality Comparison project.

This module provides standalone, beginner-friendly functions for:
- Loading and validating air quality datasets (CSV)
- Checking data quality (missing, invalid, duplicate, out-of-range values)
- Classifying AQI using India's CPCB National Air Quality Index standards
- Calculating city averages and rankings
- Threshold filtering and category distributions
- Validating and safely appending new observations

Designed for clarity and educational data science projects (BCA / B.Sc / B.Tech).
No complex abstractions, decorators, or heavy machine-learning libraries.
"""

from datetime import datetime
import os
import numpy as np
import pandas as pd

# ---------------------------------------------------------------------------
# Constants and Standards
# ---------------------------------------------------------------------------

# Required columns for the air quality dataset
REQUIRED_COLUMNS = [
    "Observation_ID",
    "City",
    "Observation_Date",
    "AQI",
    "PM2_5",
    "PM10",
    "NO2",
    "SO2",
    "CO",
]

# Pollutant concentrations and their standard educational units:
# PM2.5, PM10, NO2, SO2 in ug/m3; CO in mg/m3; AQI is unitless.
POLLUTANT_UNITS = {
    "AQI": "Index (0-500)",
    "PM2_5": "\u03bcg/m\u00b3",
    "PM10": "\u03bcg/m\u00b3",
    "NO2": "\u03bcg/m\u00b3",
    "SO2": "\u03bcg/m\u00b3",
    "CO": "mg/m\u00b3",
}

# Standard CPCB (Central Pollution Control Board, India) AQI Categories
AQI_CATEGORIES = [
    "Good",
    "Satisfactory",
    "Moderately Polluted",
    "Poor",
    "Very Poor",
    "Severe",
]

# Standard category range boundaries (inclusive)
AQI_RANGES = {
    "Good": (0, 50),
    "Satisfactory": (51, 100),
    "Moderately Polluted": (101, 200),
    "Poor": (201, 300),
    "Very Poor": (301, 400),
    "Severe": (401, 500),
}


# ---------------------------------------------------------------------------
# Data Loading and Column Validation
# ---------------------------------------------------------------------------


def load_air_quality_data(filepath="city_air_quality.csv"):
    """
    Load the air quality CSV file into a Pandas DataFrame.

    Parameters:
        filepath (str): Path to the CSV file.

    Returns:
        tuple: (df, error_message)
               If successful, df is a Pandas DataFrame and error_message is None.
               If failed, df is None and error_message contains a description.
    """
    if not os.path.exists(filepath):
        return (
            None,
            f"Dataset file '{filepath}' was not found. Please ensure the file is present in the project directory.",
        )

    try:
        # Load CSV using pandas
        df = pd.read_csv(filepath)

        # Convert column names to stripped strings to avoid leading/trailing whitespace bugs
        df.columns = [str(col).strip() for col in df.columns]

        # Convert numeric columns to numeric types, coercing errors to NaN
        numeric_cols = ["AQI", "PM2_5", "PM10", "NO2", "SO2", "CO"]
        for col in numeric_cols:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors="coerce")

        return df, None

    except Exception as e:
        return None, f"Error reading dataset file: {str(e)}"


def validate_columns(df):
    """
    Verify that all required columns exist in the DataFrame.

    Parameters:
        df (pd.DataFrame): DataFrame to inspect.

    Returns:
        tuple: (is_valid, missing_columns)
    """
    if df is None:
        return False, REQUIRED_COLUMNS

    missing_cols = [col for col in REQUIRED_COLUMNS if col not in df.columns]
    is_valid = len(missing_cols) == 0
    return is_valid, missing_cols


# ---------------------------------------------------------------------------
# AQI Classification
# ---------------------------------------------------------------------------


def classify_aqi(aqi_value):
    """
    Classify a numeric AQI value according to the Indian National AQI (CPCB) standard.

    Categories:
        - Good: 0 to 50
        - Satisfactory: 51 to 100
        - Moderately Polluted: 101 to 200
        - Poor: 201 to 300
        - Very Poor: 301 to 400
        - Severe: 401 to 500

    Rules:
        - Returns None if AQI is missing (NaN), negative, or exceeds 500.
        - Does not assign a category to invalid or out-of-range values.

    Parameters:
        aqi_value (float or int or None): The AQI number to evaluate.

    Returns:
        str or None: Category name, or None if invalid or missing.
    """
    # Check if value is None, NaN, or non-numeric
    if aqi_value is None or pd.isna(aqi_value):
        return None

    try:
        val = float(aqi_value)
    except (ValueError, TypeError):
        return None

    # Enforce standard boundaries [0, 500]
    if val < 0 or val > 500:
        return None

    if val <= 50:
        return "Good"
    elif val <= 100:
        return "Satisfactory"
    elif val <= 200:
        return "Moderately Polluted"
    elif val <= 300:
        return "Poor"
    elif val <= 400:
        return "Very Poor"
    else:
        return "Severe"


# ---------------------------------------------------------------------------
# Date Validation Helper
# ---------------------------------------------------------------------------


def is_valid_date_format(date_str):
    """
    Check if a string represents a valid, parseable date in YYYY-MM-DD format.

    Parameters:
        date_str (str): Date text to check.

    Returns:
        bool: True if valid date, False otherwise.
    """
    if pd.isna(date_str) or not isinstance(date_str, str):
        return False
    date_str = date_str.strip()
    try:
        datetime.strptime(date_str, "%Y-%m-%d")
        return True
    except ValueError:
        return False


# ---------------------------------------------------------------------------
# Data Quality and Validation Engine
# ---------------------------------------------------------------------------


def check_data_quality(df):
    """
    Perform a comprehensive, transparent data-quality check on the dataset.

    Checks for:
    1. Missing city names
    2. Missing AQI and pollutant concentrations
    3. Duplicate Observation IDs
    4. Negative AQI values (impossible)
    5. Out-of-range AQI values (> 500 under CPCB standard)
    6. Negative pollutant concentrations (impossible physical measurements)
    7. Invalid or unparseable observation dates

    Parameters:
        df (pd.DataFrame): The dataset to inspect.

    Returns:
        dict: A comprehensive dictionary with counts, issue descriptions,
              and a DataFrame containing flagged problematic records with reasons.
    """
    if df is None or df.empty:
        return {
            "total_rows": 0,
            "missing_counts": {},
            "duplicate_ids_count": 0,
            "negative_aqi_count": 0,
            "out_of_range_aqi_count": 0,
            "negative_pollutant_count": 0,
            "invalid_dates_count": 0,
            "missing_city_count": 0,
            "problematic_df": pd.DataFrame(),
            "clean_rows_count": 0,
        }

    total_rows = len(df)

    # 1. Missing values per column
    missing_counts = df.isna().sum().to_dict()

    # 2. Duplicate observation IDs
    duplicate_mask = (
        df["Observation_ID"].duplicated(keep=False)
        & df["Observation_ID"].notna()
    )
    duplicate_ids_count = int(df["Observation_ID"].duplicated().sum())

    # 3. Missing City names (null or empty string)
    missing_city_mask = (
        df["City"].isna() | (df["City"].astype(str).str.strip() == "")
    )
    missing_city_count = int(missing_city_mask.sum())

    # 4. Negative AQI values
    negative_aqi_mask = df["AQI"].notna() & (df["AQI"] < 0)
    negative_aqi_count = int(negative_aqi_mask.sum())

    # 5. Out-of-range AQI values (> 500)
    out_of_range_aqi_mask = df["AQI"].notna() & (df["AQI"] > 500)
    out_of_range_aqi_count = int(out_of_range_aqi_mask.sum())

    # 6. Negative pollutant concentrations (PM2_5, PM10, NO2, SO2, CO)
    pollutant_cols = ["PM2_5", "PM10", "NO2", "SO2", "CO"]
    negative_pollutant_mask = pd.Series(False, index=df.index)
    for col in pollutant_cols:
        if col in df.columns:
            negative_pollutant_mask = negative_pollutant_mask | (
                df[col].notna() & (df[col] < 0)
            )
    negative_pollutant_count = int(negative_pollutant_mask.sum())

    # 7. Invalid dates
    invalid_dates_mask = pd.Series(False, index=df.index)
    if "Observation_Date" in df.columns:
        invalid_dates_mask = ~df["Observation_Date"].apply(is_valid_date_format)
    invalid_dates_count = int(invalid_dates_mask.sum())

    # Compile a detailed list of reasons for each flagged row
    problem_records = []
    for idx, row in df.iterrows():
        issues = []

        # Check duplicates
        if duplicate_mask.loc[idx]:
            issues.append(f"Duplicate Observation_ID: '{row['Observation_ID']}'")

        # Check City
        if missing_city_mask.loc[idx]:
            issues.append("Missing City name")

        # Check Date
        if invalid_dates_mask.loc[idx]:
            issues.append(f"Invalid Date format: '{row['Observation_Date']}'")

        # Check AQI
        if pd.isna(row["AQI"]):
            issues.append("Missing AQI value")
        elif row["AQI"] < 0:
            issues.append(f"Negative AQI ({row['AQI']}) is invalid")
        elif row["AQI"] > 500:
            issues.append(f"AQI ({row['AQI']}) exceeds standard CPCB scale (0-500)")

        # Check Pollutants
        for col in pollutant_cols:
            if col in df.columns:
                if pd.isna(row[col]):
                    issues.append(f"Missing {col}")
                elif row[col] < 0:
                    issues.append(f"Negative {col} ({row[col]} {POLLUTANT_UNITS.get(col, '')}) is impossible")

        if issues:
            problem_row = row.copy()
            problem_row["Identified_Issues"] = "; ".join(issues)
            problem_records.append(problem_row)

    if problem_records:
        problematic_df = pd.DataFrame(problem_records)
    else:
        problematic_df = pd.DataFrame()

    problem_indices = set(problematic_df.index) if not problematic_df.empty else set()
    clean_rows_count = total_rows - len(problem_indices)

    return {
        "total_rows": total_rows,
        "missing_counts": missing_counts,
        "duplicate_ids_count": duplicate_ids_count,
        "negative_aqi_count": negative_aqi_count,
        "out_of_range_aqi_count": out_of_range_aqi_count,
        "negative_pollutant_count": negative_pollutant_count,
        "invalid_dates_count": invalid_dates_count,
        "missing_city_count": missing_city_count,
        "problematic_df": problematic_df,
        "clean_rows_count": clean_rows_count,
    }


# ---------------------------------------------------------------------------
# Clean Subsets for Analysis
# ---------------------------------------------------------------------------


def get_valid_aqi_records(df):
    """
    Return a copy of the dataset containing only records with a valid City
    and a valid numeric AQI within the standard range [0, 500].
    Also adds a 'Category' column.

    Parameters:
        df (pd.DataFrame): Original DataFrame.

    Returns:
        pd.DataFrame: Cleaned DataFrame with valid AQI and 'Category' column.
    """
    if df is None or df.empty:
        return pd.DataFrame()

    # Filter for valid non-empty city and valid AQI
    valid_mask = (
        df["City"].notna()
        & (df["City"].astype(str).str.strip() != "")
        & df["AQI"].notna()
        & (df["AQI"] >= 0)
        & (df["AQI"] <= 500)
    )

    clean_df = df[valid_mask].copy()
    clean_df["Category"] = clean_df["AQI"].apply(classify_aqi)
    return clean_df


# ---------------------------------------------------------------------------
# City Averages and Comparison
# ---------------------------------------------------------------------------


def calculate_city_averages(df, min_valid_obs=1):
    """
    Calculate average pollution metrics for each city using valid observations.

    Rules:
    - Only observations with a valid City and valid AQI [0, 500] are counted for AQI.
    - Pollutant values that are negative are excluded from that pollutant's average.
    - Missing pollutant values are not treated as zero; they are simply ignored.
    - Cities with fewer than min_valid_obs are flagged as 'Insufficient Data'.

    Parameters:
        df (pd.DataFrame): Dataset to aggregate.
        min_valid_obs (int): Minimum required valid AQI observations to calculate a ranking.

    Returns:
        pd.DataFrame: Aggregated city metrics.
    """
    if df is None or df.empty:
        return pd.DataFrame()

    # Filter records with a valid city
    valid_city_df = df[
        df["City"].notna() & (df["City"].astype(str).str.strip() != "")
    ].copy()

    if valid_city_df.empty:
        return pd.DataFrame()

    # Clean negative pollutant values to NaN so they do not corrupt averages
    pollutant_cols = ["PM2_5", "PM10", "NO2", "SO2", "CO"]
    for col in pollutant_cols:
        if col in valid_city_df.columns:
            valid_city_df.loc[valid_city_df[col] < 0, col] = np.nan

    # Clean AQI outside [0, 500] to NaN
    valid_city_df.loc[
        (valid_city_df["AQI"] < 0) | (valid_city_df["AQI"] > 500), "AQI"
    ] = np.nan

    # Group by city and calculate means and counts
    cities = []
    for city_name, group in valid_city_df.groupby("City"):
        valid_aqi_count = int(group["AQI"].notna().sum())
        total_obs = len(group)

        avg_aqi = round(group["AQI"].mean(), 1) if valid_aqi_count > 0 else np.nan
        avg_pm25 = (
            round(group["PM2_5"].mean(), 1)
            if group["PM2_5"].notna().sum() > 0
            else np.nan
        )
        avg_pm10 = (
            round(group["PM10"].mean(), 1)
            if group["PM10"].notna().sum() > 0
            else np.nan
        )
        avg_no2 = (
            round(group["NO2"].mean(), 1)
            if group["NO2"].notna().sum() > 0
            else np.nan
        )
        avg_so2 = (
            round(group["SO2"].mean(), 1)
            if group["SO2"].notna().sum() > 0
            else np.nan
        )
        avg_co = (
            round(group["CO"].mean(), 2)
            if group["CO"].notna().sum() > 0
            else np.nan
        )

        has_sufficient_data = valid_aqi_count >= min_valid_obs

        cities.append(
            {
                "City": city_name,
                "Total_Observations": total_obs,
                "Valid_AQI_Observations": valid_aqi_count,
                "Average_AQI": avg_aqi,
                "Average_PM2_5": avg_pm25,
                "Average_PM10": avg_pm10,
                "Average_NO2": avg_no2,
                "Average_SO2": avg_so2,
                "Average_CO": avg_co,
                "AQI_Category": classify_aqi(avg_aqi) if pd.notna(avg_aqi) else "N/A",
                "Data_Status": "Sufficient" if has_sufficient_data else "Insufficient Data",
            }
        )

    summary_df = pd.DataFrame(cities)
    return summary_df


# ---------------------------------------------------------------------------
# City Ranking
# ---------------------------------------------------------------------------


def rank_cities_by_aqi(df, min_valid_obs=1, higher_is_worse=True):
    """
    Rank cities based on their average valid AQI.

    Educational Note:
    - Under the Indian National AQI scale, a HIGHER AQI value indicates
      higher air pollution and POORER air quality.
    - Therefore, by default, cities are sorted from highest average AQI to lowest.
      Rank 1 corresponds to the city with the highest average AQI (Most Polluted).
    - Cities with fewer than min_valid_obs are separated and not assigned a misleading rank.

    Parameters:
        df (pd.DataFrame): Original DataFrame.
        min_valid_obs (int): Minimum required valid AQI observations.
        higher_is_worse (bool): If True, Rank 1 is highest AQI. If False, Rank 1 is lowest AQI.

    Returns:
        tuple: (ranked_df, insufficient_data_df)
    """
    city_avg_df = calculate_city_averages(df, min_valid_obs=min_valid_obs)

    if city_avg_df.empty:
        return pd.DataFrame(), pd.DataFrame()

    # Split into cities with sufficient valid AQI data vs insufficient
    sufficient_df = city_avg_df[
        (city_avg_df["Data_Status"] == "Sufficient")
        & city_avg_df["Average_AQI"].notna()
    ].copy()

    insufficient_df = city_avg_df[
        (city_avg_df["Data_Status"] != "Sufficient")
        | city_avg_df["Average_AQI"].isna()
    ].copy()

    if not sufficient_df.empty:
        # Sort by Average AQI
        sufficient_df = sufficient_df.sort_values(
            by="Average_AQI", ascending=not higher_is_worse
        ).reset_index(drop=True)
        # Assign 1-based rank
        sufficient_df["Rank"] = sufficient_df.index + 1

        # Rearrange columns so Rank is first
        cols = ["Rank"] + [c for c in sufficient_df.columns if c != "Rank"]
        sufficient_df = sufficient_df[cols]

    return sufficient_df, insufficient_df


# ---------------------------------------------------------------------------
# Threshold Filtering
# ---------------------------------------------------------------------------


def filter_by_threshold(
    df,
    aqi_thresh=None,
    pm25_thresh=None,
    pm10_thresh=None,
    selected_city=None,
    condition=">=",
):
    """
    Filter observations that exceed user-defined environmental thresholds.

    Parameters:
        df (pd.DataFrame): Dataset to filter.
        aqi_thresh (float, optional): Threshold for AQI.
        pm25_thresh (float, optional): Threshold for PM2.5 (ug/m3).
        pm10_thresh (float, optional): Threshold for PM10 (ug/m3).
        selected_city (str, optional): Filter by a specific city, or 'All Cities'.
        condition (str): Either '>=' (greater than or equal) or '>' (strictly greater than).

    Returns:
        pd.DataFrame: Filtered observations matching the criteria.
    """
    if df is None or df.empty:
        return pd.DataFrame()

    filtered = df.copy()

    # Optional City filter
    if selected_city and selected_city != "All Cities":
        filtered = filtered[filtered["City"] == selected_city]

    # Helper function for condition comparison
    def check_condition(series_val, thresh_val):
        if thresh_val is None:
            return pd.Series(True, index=series_val.index)
        if condition == ">":
            return series_val.notna() & (series_val > thresh_val)
        else:  # default to '>='
            return series_val.notna() & (series_val >= thresh_val)

    mask = pd.Series(True, index=filtered.index)

    if aqi_thresh is not None:
        mask = mask & check_condition(filtered["AQI"], aqi_thresh)

    if pm25_thresh is not None:
        mask = mask & check_condition(filtered["PM2_5"], pm25_thresh)

    if pm10_thresh is not None:
        mask = mask & check_condition(filtered["PM10"], pm10_thresh)

    return filtered[mask].copy()


# ---------------------------------------------------------------------------
# AQI Category Distribution
# ---------------------------------------------------------------------------


def count_aqi_categories(df):
    """
    Count valid observations in each CPCB AQI category and compute percentages.

    Rules:
    - Observations with missing, negative, or > 500 AQI are excluded from the category denominator.
    - Clearly counts and reports the number of excluded records.
    - Percentages strictly add up to 100% of valid categorized records.
    - All 6 categories are always included in the returned table for completeness.

    Parameters:
        df (pd.DataFrame): Dataset to analyze.

    Returns:
        tuple: (category_summary_df, total_valid_categorized, total_excluded)
    """
    if df is None or df.empty:
        empty_cat = pd.DataFrame(
            {
                "Category": AQI_CATEGORIES,
                "AQI_Range": [
                    f"{AQI_RANGES[c][0]}-{AQI_RANGES[c][1]}" for c in AQI_CATEGORIES
                ],
                "Count": [0] * len(AQI_CATEGORIES),
                "Percentage (%)": [0.0] * len(AQI_CATEGORIES),
            }
        )
        return empty_cat, 0, 0

    valid_records = get_valid_aqi_records(df)
    total_valid = len(valid_records)
    total_excluded = len(df) - total_valid

    # Count occurrences for each category
    counts_series = valid_records["Category"].value_counts()

    rows = []
    for cat in AQI_CATEGORIES:
        cnt = int(counts_series.get(cat, 0))
        pct = round((cnt / total_valid * 100), 1) if total_valid > 0 else 0.0
        range_str = f"{AQI_RANGES[cat][0]} - {AQI_RANGES[cat][1]}"
        rows.append(
            {
                "Category": cat,
                "AQI_Range": range_str,
                "Count": cnt,
                "Percentage (%)": pct,
            }
        )

    summary_df = pd.DataFrame(rows)
    return summary_df, total_valid, total_excluded


# ---------------------------------------------------------------------------
# Add Observation Validation and Persistence
# ---------------------------------------------------------------------------


def validate_new_observation(
    existing_df,
    obs_id,
    city,
    obs_date,
    aqi,
    pm2_5,
    pm10,
    no2,
    so2,
    co,
):
    """
    Validate all fields before adding a new observation.

    Validation rules:
    - Observation_ID is required and must be unique.
    - City is required and cannot be empty.
    - Observation_Date must be a valid date in YYYY-MM-DD format.
    - AQI must be an integer or float between 0 and 500 (or None if missing).
    - Pollutant values (PM2_5, PM10, NO2, SO2, CO) cannot be negative.
    - Missing pollutant values are permitted and preserved as None (not fabricated).

    Returns:
        tuple: (is_valid, error_list, cleaned_record_dict)
    """
    errors = []

    # 1. Observation_ID check
    clean_id = str(obs_id).strip() if obs_id is not None else ""
    if not clean_id:
        errors.append("Observation ID is required and cannot be blank.")
    elif existing_df is not None and not existing_df.empty:
        if clean_id in existing_df["Observation_ID"].astype(str).values:
            errors.append(f"Observation ID '{clean_id}' already exists. Please choose a unique ID.")

    # 2. City check
    clean_city = str(city).strip() if city is not None else ""
    if not clean_city:
        errors.append("City name is required and cannot be blank.")

    # 3. Date check
    clean_date = str(obs_date).strip() if obs_date is not None else ""
    if not clean_date or not is_valid_date_format(clean_date):
        errors.append("Observation Date must be in valid YYYY-MM-DD format (e.g. 2024-03-15).")

    # Helper function to check and convert numeric values
    def parse_numeric(val, field_name, min_val=0.0, max_val=None, allow_none=True):
        if val is None or val == "" or pd.isna(val):
            if allow_none:
                return None
            else:
                errors.append(f"{field_name} is required.")
                return None
        try:
            num = float(val)
            if min_val is not None and num < min_val:
                errors.append(f"{field_name} cannot be negative ({num}).")
            if max_val is not None and num > max_val:
                errors.append(f"{field_name} cannot exceed {max_val} ({num}).")
            return num
        except (ValueError, TypeError):
            errors.append(f"{field_name} must be a valid numeric value.")
            return None

    # 4. AQI check (0 to 500)
    clean_aqi = parse_numeric(aqi, "AQI", min_val=0, max_val=500, allow_none=True)

    # 5. Pollutants check (>= 0)
    clean_pm25 = parse_numeric(pm2_5, "PM2.5", min_val=0.0, allow_none=True)
    clean_pm10 = parse_numeric(pm10, "PM10", min_val=0.0, allow_none=True)
    clean_no2 = parse_numeric(no2, "NO2", min_val=0.0, allow_none=True)
    clean_so2 = parse_numeric(so2, "SO2", min_val=0.0, allow_none=True)
    clean_co = parse_numeric(co, "CO", min_val=0.0, allow_none=True)

    if errors:
        return False, errors, None

    record = {
        "Observation_ID": clean_id,
        "City": clean_city,
        "Observation_Date": clean_date,
        "AQI": clean_aqi,
        "PM2_5": clean_pm25,
        "PM10": clean_pm10,
        "NO2": clean_no2,
        "SO2": clean_so2,
        "CO": clean_co,
    }

    return True, [], record


def save_observation_to_csv(filepath, record_dict):
    """
    Safely append a single new observation to the CSV file.

    Parameters:
        filepath (str): Path to the CSV file.
        record_dict (dict): Dictionary of column values to append.

    Returns:
        tuple: (success, error_message)
    """
    try:
        new_row_df = pd.DataFrame([record_dict])
        # Write or append
        if os.path.exists(filepath):
            new_row_df.to_csv(filepath, mode="a", header=False, index=False)
        else:
            new_row_df.to_csv(filepath, mode="w", header=True, index=False)
        return True, None
    except Exception as e:
        return False, f"Failed to save observation to CSV: {str(e)}"
