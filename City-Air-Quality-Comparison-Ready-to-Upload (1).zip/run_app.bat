@echo off
setlocal
title City Air Quality Comparison - Launcher

echo ============================================================
echo      CITY AIR QUALITY COMPARISON - STREAMLIT LAUNCHER
echo ============================================================
echo.

:: Navigate to script directory
cd /d "%~dp0"

:: 1. Check if Python is installed and available in PATH
where python >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Python was not found on your system PATH!
    echo Please install Python 3.9+ from https://www.python.org/
    echo Make sure to check the box "Add Python to PATH" during installation.
    echo.
    pause
    exit /b 1
)

echo [OK] Python detected:
python --version
echo.

:: 2. Check if Streamlit is installed
python -m streamlit --version >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo [INFO] Dependencies not detected. Installing from requirements.txt...
    python -m pip install -r requirements.txt
    if %ERRORLEVEL% NEQ 0 (
        echo [ERROR] Failed to install required packages!
        echo Please verify your internet connection and run:
        echo   pip install -r requirements.txt
        echo.
        pause
        exit /b 1
    )
    echo [OK] Dependencies installed successfully.
    echo.
)

:: 3. Launch Streamlit Application
echo [INFO] Launching City Air Quality Comparison Dashboard...
echo [INFO] The dashboard will open in your default browser shortly.
echo [INFO] Press Ctrl+C in this window when you want to stop the app.
echo.

python -m streamlit run app.py

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [ERROR] Application terminated with an error!
    echo Please check the error messages above.
    pause
    exit /b %ERRORLEVEL%
)

endlocal
