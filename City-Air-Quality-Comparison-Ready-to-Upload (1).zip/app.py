"""
app.py
======
City Air Quality Comparison - Interactive Environmental Data Analysis Studio

A redesigned, beginner-friendly environmental research interface for BCA / Data Science students.
Features a compact horizontal navigation layout using native Streamlit tabs, an independent
environmental aesthetic (deep forest green, muted teal, warm neutral background), and complete
analytical capabilities across city comparisons, rankings, thresholds, category shares, and
transparent data-quality auditing.

Strictly utilizes native Streamlit components and charts (no external charting packages).
"""

from datetime import date, datetime
import numpy as np
import pandas as pd
import streamlit as st

import air_quality_analysis as aqa

# ---------------------------------------------------------------------------
# Streamlit Page Configuration
# ---------------------------------------------------------------------------
st.set_page_config(
    page_title="City Air Quality Comparison",
    page_icon="🍃",
    layout="wide",
    initial_sidebar_state="collapsed",
)

# ---------------------------------------------------------------------------
# Independent Environmental Visual Identity (Minimal Custom CSS)
# ---------------------------------------------------------------------------
st.markdown(
    """
    <style>
    /* Global container spacing: ensure ample top padding so content is never clipped by Streamlit header */
    .block-container {
        padding-top: 5rem;
        padding-bottom: 2.5rem;
        padding-left: 2rem;
        padding-right: 2rem;
    }
    
    /* Header bar wrapper */
    .app-header {
        padding-top: 0.25rem;
        padding-bottom: 0.25rem;
    }
    
    /* Metric cards: research style with forest green accents */
    div[data-testid="stMetric"] {
        background-color: #FFFFFF;
        border: 1px solid #D8E2DC;
        border-left: 4px solid #2D6A4F;
        padding: 12px 16px;
        border-radius: 6px;
    }
    div[data-testid="stMetric"] label {
        font-size: 0.82rem;
        font-weight: 600;
        color: #4A5568;
    }
    div[data-testid="stMetric"] div[data-testid="stMetricValue"] {
        font-size: 1.45rem;
        font-weight: 700;
        color: #1B4332;
    }
    
    /* Synthetic sample notice banner */
    .env-notice-banner {
        background-color: #F0F7F4;
        border: 1px solid #B7E4C7;
        border-left: 4px solid #2D6A4F;
        padding: 10px 14px;
        border-radius: 4px;
        font-size: 0.88rem;
        color: #1B4332;
        margin-bottom: 1rem;
    }
    
    /* Warning/Interpretation advisory banner */
    .env-advisory-banner {
        background-color: #FFFDF0;
        border: 1px solid #FFEAA7;
        border-left: 4px solid #D97706;
        padding: 10px 14px;
        border-radius: 4px;
        font-size: 0.88rem;
        color: #78350F;
        margin-bottom: 1rem;
    }

    /* Tab styling: clear hierarchy */
    button[data-baseweb="tab"] {
        font-size: 0.95rem;
        font-weight: 500;
        padding-top: 8px;
        padding-bottom: 8px;
    }
    button[data-baseweb="tab"][aria-selected="true"] {
        color: #1B4332 !important;
        font-weight: 700 !important;
        border-bottom-color: #2D6A4F !important;
    }

    /* Subtle footer */
    .env-footer {
        border-top: 1px solid #E2E8F0;
        margin-top: 3rem;
        padding-top: 1rem;
        padding-bottom: 1rem;
        font-size: 0.82rem;
        color: #64748B;
        text-align: center;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

# ---------------------------------------------------------------------------
# Session State Initialization and Data Loading
# ---------------------------------------------------------------------------
CSV_FILEPATH = "city_air_quality.csv"

if "df" not in st.session_state:
    loaded_df, load_err = aqa.load_air_quality_data(CSV_FILEPATH)
    if loaded_df is not None:
        st.session_state.df = loaded_df
        st.session_state.load_error = None
    else:
        st.session_state.df = None
        st.session_state.load_error = load_err

if "user_added_ids" not in st.session_state:
    st.session_state.user_added_ids = []


def reload_data():
    """Reload the dataset from the CSV file into session state."""
    loaded_df, load_err = aqa.load_air_quality_data(CSV_FILEPATH)
    st.session_state.df = loaded_df
    st.session_state.load_error = load_err
    st.session_state.user_added_ids = []


# ---------------------------------------------------------------------------
# Check Dataset Availability & Schema Validation
# ---------------------------------------------------------------------------
if st.session_state.df is None:
    st.error(f"⚠️ Cannot load dataset: {st.session_state.load_error}")
    st.info(
        "Please ensure `city_air_quality.csv` exists in the project root directory and is formatted correctly."
    )
    st.stop()

is_valid_cols, missing_cols = aqa.validate_columns(st.session_state.df)
if not is_valid_cols:
    st.error(
        f"⚠️ Dataset schema error: Missing required column(s): {', '.join(missing_cols)}"
    )
    st.stop()

df = st.session_state.df


# ---------------------------------------------------------------------------
# 1. Compact Header Area (Replacing persistent sidebar)
# ---------------------------------------------------------------------------
header_col1, header_col2 = st.columns([3.8, 1.2], gap="medium", vertical_alignment="center")

with header_col1:
    st.markdown(
        """
        <div class="app-header">
            <div style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
                <h2 style="color: #1B4332; margin: 0; padding: 0; font-size: 1.75rem; font-weight: 700; line-height: 1.25;">
                    City Air Quality Comparison
                </h2>
                <span style="background-color: #E8F5E9; color: #2D6A4F; font-size: 0.75rem; font-weight: 600; padding: 3px 9px; border-radius: 12px; border: 1px solid #C8E6C9; white-space: nowrap;">
                    CPCB NAQI Standard
                </span>
                <span style="background-color: #F8FAFC; color: #475569; font-size: 0.75rem; font-weight: 600; padding: 3px 9px; border-radius: 12px; border: 1px solid #E2E8F0; white-space: nowrap;">
                    Synthetic Research Dataset
                </span>
            </div>
            <p style="color: #52796F; font-size: 0.88rem; margin: 4px 0 0 0; line-height: 1.4;">
                Comparative Environmental Data Analysis, Data-Quality Auditing & Air Quality Index Evaluation
            </p>
        </div>
        """,
        unsafe_allow_html=True,
    )

with header_col2:
    if st.button("🔄 Reload Dataset", help="Reset data from city_air_quality.csv", use_container_width=True):
        reload_data()
        st.rerun()

st.markdown("<div style='margin-top: 0.25rem; margin-bottom: 0.85rem; border-bottom: 1.5px solid #D8E2DC;'></div>", unsafe_allow_html=True)


# ---------------------------------------------------------------------------
# 2. Horizontal Navigation Tabs
# ---------------------------------------------------------------------------
tab_overview, tab_comp, tab_rank, tab_thresh, tab_cat, tab_quality, tab_add, tab_dataset, tab_method = st.tabs(
    [
        "Overview",
        "City Comparison",
        "City Ranking",
        "Threshold Analysis",
        "AQI Categories",
        "Data Quality",
        "Add Observation",
        "Dataset",
        "Findings & Method",
    ]
)


# ===========================================================================
# TAB 1: OVERVIEW
# ===========================================================================
with tab_overview:
    # Visible notice that dataset contains synthetic sample observations
    st.markdown(
        """
        <div class="env-notice-banner">
            <strong>Environmental Dataset Notice:</strong> This platform utilizes <strong>synthetic sample observations</strong>
            created to demonstrate responsible environmental data analysis, CPCB NAQI standard classification, and data-cleaning
            protocols. Data points do not reflect live or officially measured municipal conditions.
        </div>
        """,
        unsafe_allow_html=True,
    )

    # Calculate actual summary metrics
    valid_records = aqa.get_valid_aqi_records(df)
    quality_summary = aqa.check_data_quality(df)
    city_averages = aqa.calculate_city_averages(df, min_valid_obs=1)

    total_obs = len(df)
    num_cities = df["City"].dropna().nunique()
    clean_obs_count = quality_summary["clean_rows_count"]
    issue_obs_count = len(quality_summary["problematic_df"])

    if not valid_records.empty:
        avg_aqi = round(valid_records["AQI"].mean(), 1)
        min_aqi = int(valid_records["AQI"].min())
        max_aqi = int(valid_records["AQI"].max())
    else:
        avg_aqi, min_aqi, max_aqi = "N/A", "N/A", "N/A"

    # Compact metric cards
    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Total Observations", total_obs, help="Total rows present in the working dataset")
    m2.metric("Cities Represented", num_cities, help="Number of distinct cities with recorded observations")
    m3.metric("Average Valid AQI", avg_aqi, help="Mean AQI across valid observations (0-500)")
    m4.metric("Data Quality Issues", issue_obs_count, help="Observations flagged with missing, duplicate, or invalid values")

    st.markdown("<div style='height: 12px;'></div>", unsafe_allow_html=True)

    # Visual Overview: Two prominent native charts
    chart_col1, chart_col2 = st.columns(2)

    with chart_col1:
        st.markdown("#### AQI Category Distribution (Valid Observations)")
        cat_summary, total_valid, excluded_count = aqa.count_aqi_categories(df)
        cat_chart_data = cat_summary.set_index("Category")[["Count"]]
        st.bar_chart(cat_chart_data, color="#2D6A4F")
        st.caption(f"Categorized {total_valid} valid records ({excluded_count} excluded due to missing/out-of-scale AQI).")

    with chart_col2:
        st.markdown("#### Average AQI Across Cities")
        if not city_averages.empty:
            city_chart_data = city_averages.dropna(subset=["Average_AQI"]).set_index("City")[["Average_AQI"]]
            st.bar_chart(city_chart_data, color="#52796F")
            st.caption("City-level arithmetic averages from valid AQI observations (lower indicates cleaner air).")
        else:
            st.info("No city data available.")

    st.markdown("<div style='height: 10px;'></div>", unsafe_allow_html=True)

    # Data-supported findings section
    st.markdown("#### Key Analytical Findings")

    # Determine highest and lowest city averages from actual calculations
    if not city_averages.empty and city_averages["Average_AQI"].notna().any():
        valid_cities = city_averages.dropna(subset=["Average_AQI"]).sort_values(by="Average_AQI")
        cleanest_city = valid_cities.iloc[0]["City"]
        cleanest_aqi = valid_cities.iloc[0]["Average_AQI"]
        cleanest_cat = valid_cities.iloc[0]["AQI_Category"]

        poorest_city = valid_cities.iloc[-1]["City"]
        poorest_aqi = valid_cities.iloc[-1]["Average_AQI"]
        poorest_cat = valid_cities.iloc[-1]["AQI_Category"]
    else:
        cleanest_city, cleanest_aqi, cleanest_cat = "N/A", "N/A", "N/A"
        poorest_city, poorest_aqi, poorest_cat = "N/A", "N/A", "N/A"

    # Most frequent category
    top_cat = cat_summary.sort_values(by="Count", ascending=False).iloc[0]

    st.markdown(
        f"""
        - **Air Quality Spectrum:** Valid AQI values in this dataset range between **{min_aqi}** and **{max_aqi}**, with an overall sample mean of **{avg_aqi}**.
        - **Lowest City Average:** **{cleanest_city}** recorded the cleanest average profile at an AQI of **{cleanest_aqi}** (*{cleanest_cat}*).
        - **Highest City Average:** **{poorest_city}** recorded the most polluted average profile at an AQI of **{poorest_aqi}** (*{poorest_cat}*).
        - **Dominant Category:** The most common category observed is **{top_cat['Category']}** with **{top_cat['Count']} observations** ({top_cat['Percentage (%)']}% of valid categorized records).
        - **Data Quality Audit:** **{clean_obs_count} rows** are fully compliant, while **{issue_obs_count} records** contain transparently flagged anomalies for educational validation.
        """
    )

    # Prompt linking to the dedicated complete dataset tab
    st.info("💡 **Ready to inspect raw records?** Switch to the **Dataset** tab to filter individual rows, search cities, and download data.")


# ===========================================================================
# TAB 2: CITY COMPARISON
# ===========================================================================
with tab_comp:
    st.markdown("### Comparative City Pollution Profiles")
    st.caption("Inspect and contrast aggregated environmental indicators across selected cities")

    st.markdown(
        """
        > **Methodology:** Values shown are **city-level arithmetic averages** computed strictly from valid readings.
        > Readings with negative pollutant values or out-of-scale AQI ($>500$) are excluded so they do not corrupt the means.
        > Missing observations are ignored rather than treated as zero.
        """
    )

    city_summary_df = aqa.calculate_city_averages(df, min_valid_obs=1)

    if city_summary_df.empty:
        st.warning("No city data available for comparison.")
    else:
        all_cities_list = sorted(city_summary_df["City"].tolist())
        default_selection = all_cities_list[:5] if len(all_cities_list) >= 5 else all_cities_list

        selected_cities = st.multiselect(
            "Select Cities to Include in Comparison",
            options=all_cities_list,
            default=default_selection,
            help="Choose any combination of cities to compare side-by-side",
        )

        if not selected_cities:
            st.info("Please select at least one city from the selector above.")
        else:
            comp_df = city_summary_df[city_summary_df["City"].isin(selected_cities)].copy()

            # Comparison Summary Table
            st.markdown("#### Aggregated Metrics Table")
            display_comp = comp_df[
                [
                    "City",
                    "Total_Observations",
                    "Valid_AQI_Observations",
                    "Average_AQI",
                    "AQI_Category",
                    "Average_PM2_5",
                    "Average_PM10",
                    "Average_NO2",
                    "Average_SO2",
                    "Average_CO",
                ]
            ].copy()
            st.dataframe(display_comp, use_container_width=True)

            # Native Streamlit comparison charts
            st.markdown("#### Visual Comparisons")
            v_col1, v_col2 = st.columns(2)

            with v_col1:
                st.markdown("**Average AQI Comparison** (Index 0-500)")
                aqi_chart_data = comp_df.dropna(subset=["Average_AQI"]).set_index("City")[["Average_AQI"]]
                if not aqi_chart_data.empty:
                    st.bar_chart(aqi_chart_data, color="#2D6A4F")
                else:
                    st.info("No valid AQI data available for selected cities.")

            with v_col2:
                st.markdown("**Particulate Matter Comparison** (PM2.5 vs PM10 in µg/m³)")
                pm_chart_data = comp_df.dropna(subset=["Average_PM2_5", "Average_PM10"]).set_index("City")[
                    ["Average_PM2_5", "Average_PM10"]
                ]
                if not pm_chart_data.empty:
                    st.bar_chart(pm_chart_data)
                else:
                    st.info("No valid PM data available for selected cities.")


# ===========================================================================
# TAB 3: CITY RANKING
# ===========================================================================
with tab_rank:
    st.markdown("### City Pollution Ranking")
    st.caption("Ordered ranking of urban centers based on average valid AQI")

    st.markdown(
        """
        <div class="env-advisory-banner">
            <strong>Index Scale Clarification:</strong> Under the Indian National AQI scale, a
            <strong>higher AQI number represents higher pollutant concentration and poorer air quality</strong>.
            Rankings below are calculated from valid observations. Missing and invalid values are excluded from the averages.
        </div>
        """,
        unsafe_allow_html=True,
    )

    r_col1, r_col2 = st.columns([2, 1])
    with r_col1:
        rank_order = st.radio(
            "Ranking Sorting Perspective",
            options=[
                "Poorest Air Quality First (Rank 1 = Highest Average AQI)",
                "Cleanest Air Quality First (Rank 1 = Lowest Average AQI)",
            ],
            index=0,
            horizontal=True,
        )
    with r_col2:
        min_valid_obs_thresh = st.number_input(
            "Minimum Valid Observations Required",
            min_value=1,
            max_value=10,
            value=2,
            help="Cities with fewer valid AQI observations than this threshold are isolated from ranking.",
        )

    higher_is_worse = "Poorest Air Quality First" in rank_order

    ranked_df, insufficient_df = aqa.rank_cities_by_aqi(
        df, min_valid_obs=min_valid_obs_thresh, higher_is_worse=higher_is_worse
    )

    st.markdown("#### Ranked Cities Table")
    if not ranked_df.empty:
        display_ranked = ranked_df[
            [
                "Rank",
                "City",
                "Valid_AQI_Observations",
                "Average_AQI",
                "AQI_Category",
                "Average_PM2_5",
                "Average_PM10",
            ]
        ].copy()
        st.dataframe(display_ranked, use_container_width=True)

        top_city = ranked_df.iloc[0]
        st.markdown(
            f"**Leading city in this view:** **{top_city['City']}** with an average AQI of **{top_city['Average_AQI']}** (*{top_city['AQI_Category']}*)."
        )
    else:
        st.warning(f"No cities met the minimum threshold of {min_valid_obs_thresh} valid observations.")

    if not insufficient_df.empty:
        st.markdown("#### Cities with Insufficient Observations")
        st.info(
            f"The following cities have fewer than {min_valid_obs_thresh} valid AQI observation(s) and are excluded from the numeric ranking to prevent misleading statistical conclusions:"
        )
        st.dataframe(
            insufficient_df[["City", "Total_Observations", "Valid_AQI_Observations", "Data_Status"]],
            use_container_width=True,
        )


# ===========================================================================
# TAB 4: THRESHOLD ANALYSIS
# ===========================================================================
with tab_thresh:
    st.markdown("### Environmental Threshold Analysis")
    st.caption("Screen observations that exceed environmental reference benchmarks")

    st.markdown(
        """
        > **Educational Reference Benchmarks:** Central Pollution Control Board (CPCB) ambient 24-hour reference standards
        > define **60 µg/m³ for PM2.5** and **100 µg/m³ for PM10**, with **AQI > 200 indicating Poor air quality**.
        > Use the threshold controls below to inspect exceedances. *These filters do not represent personal medical safety thresholds.*
        """
    )

    # Threshold controls placed together at the top of the tab
    with st.container():
        t1, t2, t3 = st.columns(3)
        with t1:
            enable_aqi = st.checkbox("Filter by AQI Threshold", value=True)
            aqi_thresh_val = st.slider(
                "AQI Limit",
                min_value=0,
                max_value=500,
                value=200,
                disabled=not enable_aqi,
                help="CPCB scale standard is 0-500",
            )
        with t2:
            enable_pm25 = st.checkbox("Filter by PM2.5 Threshold", value=False)
            pm25_thresh_val = st.slider(
                "PM2.5 Limit (µg/m³)",
                min_value=0.0,
                max_value=300.0,
                value=60.0,
                step=5.0,
                disabled=not enable_pm25,
            )
        with t3:
            enable_pm10 = st.checkbox("Filter by PM10 Threshold", value=False)
            pm10_thresh_val = st.slider(
                "PM10 Limit (µg/m³)",
                min_value=0.0,
                max_value=400.0,
                value=100.0,
                step=5.0,
                disabled=not enable_pm10,
            )

        filter_sub1, filter_sub2 = st.columns([1, 1])
        with filter_sub1:
            comparison_mode = st.selectbox(
                "Comparison Operator",
                options=[
                    ">= Greater than or equal to threshold",
                    "> Strictly greater than threshold",
                ],
                index=0,
            )
        with filter_sub2:
            filter_city_opt = st.selectbox(
                "City Scope",
                options=["All Cities"] + sorted([c for c in df["City"].dropna().unique() if str(c).strip()]),
            )

    cond_op = ">=" if ">=" in comparison_mode else ">"

    # Execute filtering
    matched_df = aqa.filter_by_threshold(
        df,
        aqi_thresh=aqi_thresh_val if enable_aqi else None,
        pm25_thresh=pm25_thresh_val if enable_pm25 else None,
        pm10_thresh=pm10_thresh_val if enable_pm10 else None,
        selected_city=filter_city_opt,
        condition=cond_op,
    )

    total_in_scope = len(df[df["City"] == filter_city_opt]) if filter_city_opt != "All Cities" else len(df)
    match_count = len(matched_df)
    exceedance_pct = round(match_count / total_in_scope * 100, 1) if total_in_scope > 0 else 0.0

    st.markdown("<div style='height: 8px;'></div>", unsafe_allow_html=True)

    # Summary metrics
    tm1, tm2, tm3 = st.columns(3)
    tm1.metric("Matching Observations", match_count)
    tm2.metric("Total in Selected Scope", total_in_scope)
    tm3.metric("Exceedance Share", f"{exceedance_pct}%")

    st.markdown("#### Exceeding Observations Table")
    if matched_df.empty:
        st.info("No records in the dataset exceed the selected threshold criteria.")
    else:
        # Add classification category for clarity
        matched_display = matched_df.copy()
        matched_display["AQI_Category"] = matched_display["AQI"].apply(aqa.classify_aqi)
        st.dataframe(matched_display, use_container_width=True)


# ===========================================================================
# TAB 5: AQI CATEGORIES
# ===========================================================================
with tab_cat:
    st.markdown("### Air Quality Index Category Distribution")
    st.caption("Categorization breakdown according to the Central Pollution Control Board (CPCB) NAQI scale")

    category_summary, valid_cat_count, excluded_count = aqa.count_aqi_categories(df)

    # Disclose counts clearly
    km1, km2, km3 = st.columns(3)
    km1.metric("Valid Categorized Records", valid_cat_count)
    km2.metric("Excluded Records", excluded_count, help="Missing, negative, or > 500 AQI readings excluded from categorization")
    km3.metric("Total Dataset Rows", len(df))

    st.markdown(
        """
        > **Percentage Calculation Standard:** Percentages are computed exclusively over the **valid categorized records**
        > (where AQI is between 0 and 500). Excluded records with invalid or missing AQI are omitted from the denominator,
        > ensuring category shares sum to exactly 100.0%.
        """
    )

    cat_col_chart, cat_col_tbl = st.columns([3, 2])

    with cat_col_chart:
        st.markdown("#### Category Distribution Chart")
        cat_chart = category_summary.set_index("Category")[["Count"]]
        st.bar_chart(cat_chart, color="#2D6A4F")

    with cat_col_tbl:
        st.markdown("#### Category Share Summary")
        st.dataframe(category_summary, use_container_width=True)

    # Detailed CPCB definitions table
    with st.expander("ℹ️ Official CPCB NAQI Category Numerical Boundaries & Health Statements", expanded=True):
        st.markdown(
            """
            | Category | AQI Range | CPCB Health Description |
            | :--- | :--- | :--- |
            | **Good** | 0 – 50 | Minimal impact; clean air. |
            | **Satisfactory** | 51 – 100 | Minor breathing discomfort to sensitive people. |
            | **Moderately Polluted** | 101 – 200 | Breathing discomfort to people with lung, asthma, and heart diseases. |
            | **Poor** | 201 – 300 | Breathing discomfort to most people on prolonged exposure. |
            | **Very Poor** | 301 – 400 | Respiratory illness on prolonged exposure. |
            | **Severe** | 401 – 500 | Affects healthy people and seriously impacts those with existing diseases. |

            *Reference: Central Pollution Control Board (CPCB), Ministry of Environment, Forest and Climate Change, Government of India.*
            """
        )


# ===========================================================================
# TAB 6: DATA QUALITY
# ===========================================================================
with tab_quality:
    st.markdown("### Data Quality & Integrity Audit")
    st.caption("Transparent detection, reporting, and isolation of data anomalies")

    quality_report = aqa.check_data_quality(df)

    st.markdown(
        """
        <div class="env-notice-banner">
            <strong>Data Science Pedagogy:</strong> Environmental sensor feeds routinely contain artifacts such as zero-drift
            negatives, transmission dropouts, and duplicate packets. This dataset includes deliberate anomalies to teach
            transparent data validation without silently discarding rows or fabricating numbers.
        </div>
        """,
        unsafe_allow_html=True,
    )

    # Metric counts
    qm1, qm2, qm3, qm4, qm5 = st.columns(5)
    qm1.metric("Rows Audited", quality_report["total_rows"])
    qm2.metric("Clean Records", quality_report["clean_rows_count"])
    qm3.metric("Problematic Records", len(quality_report["problematic_df"]))
    qm4.metric("Duplicate IDs", quality_report["duplicate_ids_count"])
    qm5.metric("Missing City Entries", quality_report["missing_city_count"])

    st.markdown("#### Issue Categorization & Analytical Impact")
    issue_data = [
        {
            "Issue Category": "Duplicate Observation ID",
            "Count": quality_report["duplicate_ids_count"],
            "Analytical Impact": "Causes artificial double-counting of measurements in city averages.",
        },
        {
            "Issue Category": "Missing City Name",
            "Count": quality_report["missing_city_count"],
            "Analytical Impact": "Cannot group by city; observation must be excluded from city comparisons.",
        },
        {
            "Issue Category": "Negative AQI Value (< 0)",
            "Count": quality_report["negative_aqi_count"],
            "Analytical Impact": "AQI cannot physically be negative; corrupts arithmetic mean if not excluded.",
        },
        {
            "Issue Category": "AQI Exceeding CPCB Scale (> 500)",
            "Count": quality_report["out_of_range_aqi_count"],
            "Analytical Impact": "Exceeds standard 0-500 scale; cannot be assigned standard NAQI category.",
        },
        {
            "Issue Category": "Negative Pollutant Concentration",
            "Count": quality_report["negative_pollutant_count"],
            "Analytical Impact": "Mass concentration cannot be negative; represents sensor zero-drift error.",
        },
        {
            "Issue Category": "Invalid Date Format",
            "Count": quality_report["invalid_dates_count"],
            "Analytical Impact": "Fails date-based filtering and timeline sequence operations.",
        },
    ]
    st.dataframe(pd.DataFrame(issue_data), use_container_width=True)

    st.markdown("#### Flagged Problematic Observations")
    prob_df = quality_report["problematic_df"]
    if prob_df.empty:
        st.success("No data quality issues identified in the current dataset.")
    else:
        st.dataframe(prob_df, use_container_width=True)

    with st.expander("🛠️ Why We Do Not Silently Delete Every Problematic Record"):
        st.markdown(
            """
            In responsible environmental data analysis:
            1. **Data Provenance:** Deleting rows silently destroys the audit trail and hides sensor maintenance needs.
            2. **Selective Usability:** A record with an uncalibrated $SO_2$ sensor reading may still contain a valid $PM_{2.5}$ reading.
            3. **Transparent Filtration:** We exclude invalid readings specifically within individual calculation functions (e.g., filtering out negative $PM_{2.5}$ when calculating particulate averages) rather than discarding the entire observation.
            """
        )


# ===========================================================================
# TAB 7: ADD OBSERVATION
# ===========================================================================
with tab_add:
    st.markdown("### Record New Observation")
    st.caption("Validate and append a new environmental observation to the working dataset")

    st.markdown(
        """
        <div class="env-notice-banner">
            <strong>Cloud Environment Notice:</strong> Adding a valid observation updates your active session immediately
            and saves to the local CSV file. On cloud platforms like Streamlit Community Cloud, instances run on ephemeral containers;
            records will remain active in your session, but will not permanently survive container reboots.
        </div>
        """,
        unsafe_allow_html=True,
    )

    next_id_guess = f"OBS{len(df) + 1:03d}"

    with st.form("add_observation_form_redesign"):
        st.markdown("##### 1. Observation Metadata")
        m_c1, m_c2, m_c3 = st.columns(3)
        with m_c1:
            form_obs_id = st.text_input(
                "Observation ID *",
                value=next_id_guess,
                help="Must be a unique identifier (e.g. OBS043)",
            )
        with m_c2:
            form_city = st.text_input(
                "City Name *",
                placeholder="e.g. Bhopal",
                help="Name of urban area where observation occurred",
            )
        with m_c3:
            form_date = st.date_input("Observation Date *", value=date.today())

        st.markdown("##### 2. Environmental Measurements")
        p_c1, p_c2, p_c3 = st.columns(3)
        with p_c1:
            form_aqi = st.number_input(
                "AQI (0 to 500)",
                min_value=0,
                max_value=500,
                value=120,
                step=1,
                help="CPCB National AQI Index (0-500)",
            )
            form_pm25 = st.number_input(
                "PM2.5 (µg/m³)",
                min_value=0.0,
                max_value=500.0,
                value=45.0,
                step=0.5,
                help="Fine particulate matter",
            )
        with p_c2:
            form_pm10 = st.number_input(
                "PM10 (µg/m³)",
                min_value=0.0,
                max_value=600.0,
                value=95.0,
                step=0.5,
                help="Coarse particulate matter",
            )
            form_no2 = st.number_input(
                "NO2 (µg/m³)",
                min_value=0.0,
                max_value=300.0,
                value=35.0,
                step=0.5,
                help="Nitrogen dioxide concentration",
            )
        with p_c3:
            form_so2 = st.number_input(
                "SO2 (µg/m³)",
                min_value=0.0,
                max_value=200.0,
                value=12.0,
                step=0.5,
                help="Sulfur dioxide concentration",
            )
            form_co = st.number_input(
                "CO (mg/m³)",
                min_value=0.0,
                max_value=20.0,
                value=1.2,
                step=0.1,
                help="Carbon monoxide concentration",
            )

        submit_btn = st.form_submit_button("➕ Validate and Submit Observation", use_container_width=True)

    if submit_btn:
        is_valid, validation_errors, clean_record = aqa.validate_new_observation(
            existing_df=st.session_state.df,
            obs_id=form_obs_id,
            city=form_city,
            obs_date=form_date.strftime("%Y-%m-%d"),
            aqi=form_aqi,
            pm2_5=form_pm25,
            pm10=form_pm10,
            no2=form_no2,
            so2=form_so2,
            co=form_co,
        )

        if not is_valid:
            st.error("⚠️ Validation Failed. Please resolve the following issues:")
            for err in validation_errors:
                st.write(f"- {err}")
        else:
            new_row_df = pd.DataFrame([clean_record])
            st.session_state.df = pd.concat([st.session_state.df, new_row_df], ignore_index=True)
            st.session_state.user_added_ids.append(clean_record["Observation_ID"])

            saved, save_err = aqa.save_observation_to_csv(CSV_FILEPATH, clean_record)

            st.success(
                f"✅ Observation '{clean_record['Observation_ID']}' for **{clean_record['City']}** added successfully! All tabs updated."
            )
            if not saved:
                st.warning(f"Note: Local CSV could not be updated: {save_err}")
            else:
                st.info("Record appended to local `city_air_quality.csv`.")
            st.rerun()

    # Display records added in current session
    if st.session_state.user_added_ids:
        st.markdown("#### Observations Added in Current Session")
        added_df = st.session_state.df[st.session_state.df["Observation_ID"].isin(st.session_state.user_added_ids)]
        st.dataframe(added_df, use_container_width=True)


# ===========================================================================
# TAB 8: DATASET (Dedicated Exploration Page)
# ===========================================================================
with tab_dataset:
    st.markdown("### Complete Environmental Dataset")
    st.caption("Inspect, filter, search, and export the complete observation records")

    display_full_df = df.copy()
    display_full_df["AQI_Category"] = display_full_df["AQI"].apply(aqa.classify_aqi)

    # Filter controls for the dedicated dataset view
    with st.expander("🔍 Dataset Filter & Sort Controls", expanded=True):
        fc1, fc2, fc3 = st.columns(3)
        with fc1:
            all_cities = sorted([c for c in df["City"].dropna().unique() if str(c).strip()])
            selected_city_data = st.selectbox(
                "Filter by City",
                options=["All Cities"] + all_cities,
                key="ds_city_filter",
            )
            category_filter_data = st.multiselect(
                "Filter by AQI Category",
                options=aqa.AQI_CATEGORIES + ["Unclassified / Invalid"],
                default=[],
                key="ds_cat_filter",
            )
        with fc2:
            aqi_slider_data = st.slider(
                "AQI Value Range",
                min_value=0,
                max_value=600,
                value=(0, 500),
                key="ds_aqi_slider",
                help="Filter by AQI numerical bounds",
            )
        with fc3:
            sort_field = st.selectbox(
                "Sort Table By",
                options=["Observation_ID", "City", "Observation_Date", "AQI", "PM2_5", "PM10", "NO2", "SO2", "CO"],
                index=3,
                key="ds_sort_field",
            )
            sort_asc = st.checkbox("Ascending Order", value=False, key="ds_sort_asc")

    # Apply filters
    filtered_dataset = display_full_df.copy()
    if selected_city_data != "All Cities":
        filtered_dataset = filtered_dataset[filtered_dataset["City"] == selected_city_data]

    filtered_dataset = filtered_dataset[
        (filtered_dataset["AQI"].isna())
        | ((filtered_dataset["AQI"] >= aqi_slider_data[0]) & (filtered_dataset["AQI"] <= aqi_slider_data[1]))
    ]

    if category_filter_data:
        selected_set = set(category_filter_data)
        mask = filtered_dataset["AQI_Category"].apply(
            lambda cat: (cat in selected_set) or ("Unclassified / Invalid" in selected_set and cat is None)
        )
        filtered_dataset = filtered_dataset[mask]

    if sort_field in filtered_dataset.columns:
        filtered_dataset = filtered_dataset.sort_values(by=sort_field, ascending=sort_asc, na_position="last")

    # Metrics and table
    st.markdown(
        f"**Showing {len(filtered_dataset)} matching record(s)** out of {len(df)} total observations."
    )

    if filtered_dataset.empty:
        st.warning("No records match the chosen filter criteria.")
    else:
        st.dataframe(filtered_dataset, use_container_width=True)

        # Native CSV download button
        csv_export = filtered_dataset.to_csv(index=False).encode("utf-8")
        st.download_button(
            label="📥 Download Filtered Dataset as CSV",
            data=csv_export,
            file_name="city_air_quality_filtered.csv",
            mime="text/csv",
        )


# ===========================================================================
# TAB 9: FINDINGS & METHOD
# ===========================================================================
with tab_method:
    st.markdown("### Findings & Scientific Methodology")
    st.caption("Technical documentation, mathematical formulation, and analytical limitations")

    st.markdown(
        r"""
        #### 1. Project Purpose & Educational Framework
        The **City Air Quality Comparison** project is crafted for undergraduate computer science and data science students
        (BCA / B.Sc / B.Tech). It provides a concrete, hands-on demonstration of:
        - Applying Python, Pandas, and NumPy to real-world environmental data structures.
        - Implementing strict domain data validation: boundary testing, duplicate detection, and missing-value isolation.
        - Calculating transparent aggregation metrics without misleading approximations.
        - Presenting information using native, accessible Streamlit visualization components.

        ---

        #### 2. Dataset Schema & Variable Definitions
        Each record in `city_air_quality.csv` corresponds to a discrete monitoring event with the following attributes:
        - **`Observation_ID`** (String): Unique identifier for the measurement event (e.g. `OBS001`).
        - **`City`** (String): Urban center where the observation was gathered.
        - **`Observation_Date`** (Date String, `YYYY-MM-DD`): Observation timestamp.
        - **`AQI`** (Integer / Float): Overall Air Quality Index (0 to 500 under Indian NAQI).
        - **`PM2_5`** (Float, µg/m³): Fine particulate matter with aerodynamic diameter $\le 2.5\ \mu\text{m}$.
        - **`PM10`** (Float, µg/m³): Coarse inhalable particulate matter with aerodynamic diameter $\le 10\ \mu\text{m}$.
        - **`NO2`** (Float, µg/m³): Nitrogen dioxide concentration.
        - **`SO2`** (Float, µg/m³): Sulfur dioxide concentration.
        - **`CO`** (Float, mg/m³): Carbon monoxide concentration.

        ---

        #### 3. CPCB National AQI Classification Standard
        The Indian National Air Quality Index (NAQI) established by the **Central Pollution Control Board (CPCB)**
        converts multiple pollutant measurements into a single index value from 0 to 500:

        | Category Name | Range | General Health Description |
        | :--- | :---: | :--- |
        | **Good** | 0 – 50 | Minimal health impact; clean ambient air. |
        | **Satisfactory** | 51 – 100 | Minor breathing discomfort to sensitive individuals. |
        | **Moderately Polluted** | 101 – 200 | Breathing discomfort to people with asthma, lung, or heart conditions. |
        | **Poor** | 201 – 300 | Breathing discomfort to most people on prolonged exposure. |
        | **Very Poor** | 301 – 400 | Respiratory illness on prolonged exposure. |
        | **Severe** | 401 – 500 | Affects healthy people and seriously impacts sensitive populations. |

        **Scientific Responsibility Rule:** We do not fabricate composite AQI numbers from raw concentrations.
        Official CPCB calculations require 24-hour sub-index breakpoint equations and minimum multi-pollutant coverage.
        Here, we classify the directly supplied AQI and evaluate individual pollutant concentrations separately.

        ---

        #### 4. Mathematical Aggregations & Formulas
        - **City-Level Pollutant Mean:** For city $c$ and environmental indicator $p$:
          $$\bar{x}_{c, p} = \frac{1}{N_{\text{valid}}} \sum_{i=1}^{N_{\text{valid}}} x_{i, c, p}$$
          where invalid entries (e.g. $x < 0$ or missing) are excluded from $N_{\text{valid}}$.
        - **Category Percentage Share:**
          $$P_{\text{category}} = \frac{\text{Count in Category}}{N_{\text{valid categorized records}}} \times 100\%$$
          Excluded records (missing, negative, or $>500$ AQI) are deducted from the percentage denominator.

        ---

        #### 5. Academic Integrity & Non-Medical Notice
        - **Synthetic Sample Data:** All observations in the repository are synthetic sample data generated for instructional analysis.
        - **Non-Clinical:** AQI categories indicate ambient air pollution tiers; they do not diagnose medical conditions or serve as clinical guidance.
        - **No Unwarranted Extrapolation:** Small sample sizes cannot be extrapolated to represent multi-year urban climate trends.
        """
    )


# ---------------------------------------------------------------------------
# 3. Subtle Footer Area
# ---------------------------------------------------------------------------
st.markdown(
    """
    <div class="env-footer">
        City Air Quality Comparison • Academic Environmental Data Analysis • Central Pollution Control Board (CPCB) NAQI Standard • Synthetic Sample Dataset for Educational Demonstration
    </div>
    """,
    unsafe_allow_html=True,
)
